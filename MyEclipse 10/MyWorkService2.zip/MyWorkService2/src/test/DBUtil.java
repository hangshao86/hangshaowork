package test;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.Connection;

public class DBUtil {
      private String dbName="infosearch";
      private String url="jdbc:mysql://localhost:3306/"+dbName;
      private String user="root";
      private String psd="123456";
      private Connection conn;
      private PreparedStatement ps;
      private ResultSet rs;
      
      public Connection getConn(){
    	  try{
    		Class.forName("com.mysql.jdbc.Driver");
    		conn=DriverManager.getConnection(url,user,psd);
    		
    	  }catch (Exception e) {
			// TODO: handle exception
    		  e.printStackTrace();
		}
    	  return conn;
    	  
      }
      public boolean checkUser(String sql,String[] args){
    	  boolean flag=false;
    	  conn=getConn();
    	  try{
    		  ps=conn.prepareStatement(sql);
    		  if(args!=null)
    		  {
    			  for(int i=0;i<args.length;i++)
            	  {
            		  ps.setString(i+1, args[i]);
            	  }
    		  }
    		  rs=ps.executeQuery();
    	    	 if(rs.next())
    	    	 {
    	    		 flag=true;
    	    	 }
        	  
    	  }catch (Exception e) {
			// TODO: handle exception
    		  e.printStackTrace();
		}
    	 
    	  return flag;
      }
      public boolean add(String sql,String[] args){
    	  boolean flag=false;
    	  conn=getConn();
    	  try{
    		  ps=conn.prepareStatement(sql);
    		  if(args!=null)
    		  {
    			  for(int i=0;i<args.length;i++)
            	  {
            		  ps.setString(i+1, args[i]);
            	  }
    		  }
    		  int i=ps.executeUpdate();
    	    	 if(i==1)
    	    	 {
    	    		 flag=true;
    	    	 }
        	  
    	  }catch (Exception e) {
			// TODO: handle exception
    		  e.printStackTrace();
		}
    	 
    	  return flag;
      }
}

